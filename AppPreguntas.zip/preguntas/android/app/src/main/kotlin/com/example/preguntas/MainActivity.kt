package com.example.preguntas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
