import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

//Variable para guardar la puntuación acumulada
int score = 0;

//Método main para iniciar la ejecución de la app
void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: Inicio()),
  );
}

//Clase Inicio: Pantalla principal de la app
class Inicio extends StatefulWidget {
  const Inicio({ Key? key }) : super(key: key);

  @override
  _InicioState createState() => _InicioState();
}

class _InicioState extends State<Inicio> {

  //Método build que construye los widgets de la app
  @override
  Widget build(BuildContext context) {

    //Método que recibe parámetros específicos para crear y retornar un widget de texto personalizado
    Widget textoPersonalizado(String texto, Color color, double size, bool bold){
      return Align(
        alignment: Alignment.center,
        child: Text(
          texto,
          style: TextStyle(
            color: color,
            fontWeight: bold?FontWeight.bold:FontWeight.normal,
            fontSize: size,
          ),
        ),
      );
    }

    //El método buil, retorna el Scaffold que contiene la estructura de la app
    return Scaffold(
      //Creación de appbar o barra superior de la app, en este caso solamente la barra sin contenido
      appBar: AppBar(),
      //Widget column, para crear una columna de widgets
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          //Llamada a método enviando parámetros para crear un widget de texto personalizado
          textoPersonalizado(
            "Bienvenido",
            Colors.black,
            28,
            true
          ),
          //Widget separador con 10 pixeles de altura, para crear un espacio entre widgets
          SizedBox(height: 10),
          //Widget botón para iniciar el cuestionario
          ElevatedButton(
            //Método que contiene las acciones que se realizan al presionar el botón
            onPressed: (){
              //La variable score, se inicializa en cero, para comenzar a acumular los puntos de las respuestas correctas
              score = 0;
              print(score);
              //Al presionar el botón se realiza la llamada a la pantalla "MyApp" que contiene la pregunta 1
              Navigator.pushReplacement(
                context, 
                MaterialPageRoute(builder: (context) => MyApp())
              );
            }, 
            //Texto del botón
            child: Text("Comenzar cuestionario"),
            
          ),
          //Botón para salir de la app
          ElevatedButton(
            onPressed: (){
              score = 0;
              print(score);
              //Llamada a método para cerrar la app
              SystemNavigator.pop();
            }, 
            //Texto del botón
            child: Text("Salir"),
            
          ),
        ],
      )
    );
  }
}

//Clase MyApp: Pantalla de la pregunta 1
class MyApp extends StatefulWidget {
  const MyApp({ Key? key }) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {

  //Variable que guarda la respuesta elegida por el usuario
  String respuesta = "";
  //Variable para indicar si el usuario a elegido alguna respuesta, inicializada en true, para habilitar los radio button para responder el cuestionario
  bool activarResponder = true;

  //Método build para construir widgets de la app
  @override
  Widget build(BuildContext context) {

    //Método para crear widget de texto personalizado
    Widget textoPersonalizado(String texto, Color color, double size, bool bold){
      return Padding(
        padding: const EdgeInsets.only(top: 16.0, left: 4.0, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    //Método para crear Widget de texto que indica si la respuesta elegida es correcta o incorrecta
    Widget textoRespuesta(double size, bool bold){
      String texto;
      Color color;
      double resta;
      //Si la respuesta elegida es la número 3, el texto que se mostrará es: Respuesta correcta
      if(respuesta=="3"){
        texto = "¡Repuesta correcta!";
        color = Colors.green;
        resta = 0;
      }else{ //de lo contrario, se mostrará el texto: respuesta incorrecta.
        texto = "¡Repuesta incorrecta!";
        color = Colors.red;
        resta = 10;
      }

      //Variable que almacena el ancho de la pantalla del dispositivo
      double ancho = MediaQuery.of(context).size.width/3;
      
      //Creación del widget texto que mostrará el texto de respuesta correcta o incorrecta, y atributos como: color, tamaño, alineación, padding.
      return Padding(
        padding: EdgeInsets.only(top: 16.0, left: ancho-resta, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    //Estructura de la app
    return Scaffold(
      //Barra superior
      appBar: AppBar(),
      //Cuerpo de la app, el cual esta conformado por una columna de widgets
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          //Llamada a método que crea Widget de texto personalizado, el cual contiene la pregunta número 1.
          textoPersonalizado(
            "a) De las siguientes palabras señala cuál de ellas está escrita correctamente:",
            Colors.black,
            18,
            true
          ),
          //Widget separador con 10 pixeles
          SizedBox(height: 10),
          //Widget que crea una Fila de Widgets
          Row(
            children: [
              //El primer widget de la fila, es el botón radioButton
              Radio(
                //El valor del primer radio button es 1
                value: "1", 
                //El valor elegido se guardará en la variable respuesta
                groupValue: respuesta, 
                //Al presionar el radio button, se realizará lo siguiente;
                onChanged: activarResponder?(val){ //Si activarResponder es true, se muestra habilitado el radio button
                  respuesta = val.toString(); //La variable respuesta guarda el valor "1" de este botón
                  setState(() {
                    activarResponder = false; //La variable activarResponder, se vuelve false, para inhabilitar los radioButton para no poder seleccionar otras respuestas
                  });
                }:null, //Si activarResponder es false, se muestra inhabilitado el radio button
              ),
              //Llamada a método que crea un widget de texto personalizado con los parámetros especificados
              textoPersonalizado("a. Jiba", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "2", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("b. Jiva", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "3", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                    score += 10; //Al elegir esta respuesta, al ser la correcta, se suman 10 puntos a la variable "Score"
                  });
                }:null,
                
              ),
              textoPersonalizado("c. Giba", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "4", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("d. Giva", Colors.black, 16, false),
            ],
          ),
          SizedBox(height: 10),
          activarResponder?
          Container()
          :Align(
            alignment: Alignment.center,
            child: textoRespuesta(16, true)
          ),
          //Botón para pasar a la siguiente pregunta
          ElevatedButton(
            onPressed: activarResponder?null:(){ //Si activarResponder es true, significa que los radioButton están habilitados para responder, entonces este botón es null y se inhabilita para no poder pasar a la siguiente pregunta
              print(score);
              //Método para pasar a la pregunta 2
              Navigator.pushReplacement(
                context, 
                MaterialPageRoute(builder: (context) => Pregunta2())
              );
            }, 
            //Texto del botón
            child: Text("Siguiente"),
            
          )
        ],
      )
    );
  }
}

//Clase Pregunta 2: Pantalla de la pregunta 2
//Funcionamiento similar a la clase "MyApp", de la pantalla de la pregunta 1
class Pregunta2 extends StatefulWidget {
  const Pregunta2({ Key? key }) : super(key: key);

  @override
  _Pregunta2State createState() => _Pregunta2State();
}

class _Pregunta2State extends State<Pregunta2> {
  String respuesta = "";
  bool activarResponder = true;

  @override
  Widget build(BuildContext context) {

    Widget textoPersonalizado(String texto, Color color, double size, bool bold){
      return Padding(
        padding: const EdgeInsets.only(top: 16.0, left: 4.0, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    Widget textoRespuesta(double size, bool bold){
      String texto;
      Color color;
      double resta;
      if(respuesta=="4"){
        texto = "¡Repuesta correcta!";
        color = Colors.green;
        resta = 0;
      }else{
        texto = "¡Repuesta incorrecta!";
        color = Colors.red;
        resta = 10;
      }

      double ancho = MediaQuery.of(context).size.width/3;
      
      return Padding(
        padding: EdgeInsets.only(top: 16.0, left: ancho-resta, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          textoPersonalizado(
            "b) Con la llegada al trono de Carlos I, se instaura en España la monarquía de los Austrias, ¿Qué nombre recibía la rama hispana de la casa europea?",
            Colors.black,
            18,
            true
          ),
          SizedBox(height: 10),
          Row(
            children: [
              Radio(
                value: "1", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("a. Saboya", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "2", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("b. Estuardo", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "3", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
                
              ),
              textoPersonalizado("c. Borbón", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "4", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                    score += 10;
                  });
                }:null,
              ),
              textoPersonalizado("d. Habsburgo", Colors.black, 16, false),
            ],
          ),
          SizedBox(height: 10),
          activarResponder?
          Container()
          :Align(
            alignment: Alignment.center,
            child: textoRespuesta(16, true)
          ),
          ElevatedButton(
            onPressed: activarResponder?null:(){
              print(score);
              Navigator.pushReplacement(
                context, 
                MaterialPageRoute(builder: (context) => Pregunta3())
              );
            }, 
            child: Text("Siguiente"),
            
          )
        ],
      )
    );
  }
}

//Clase Pregunta 3: Pantalla de la pregunta 3
//Funcionamiento similar a la clase "MyApp", de la pantalla de la pregunta 1
class Pregunta3 extends StatefulWidget {
  const Pregunta3({ Key? key }) : super(key: key);

  @override
  _Pregunta3State createState() => _Pregunta3State();
}

class _Pregunta3State extends State<Pregunta3> {
  String respuesta = "";
  bool activarResponder = true;

  @override
  Widget build(BuildContext context) {

    Widget textoPersonalizado(String texto, Color color, double size, bool bold){
      return Padding(
        padding: const EdgeInsets.only(top: 16.0, left: 4.0, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    Widget textoRespuesta(double size, bool bold){
      String texto;
      Color color;
      double resta;
      if(respuesta=="3"){
        texto = "¡Repuesta correcta!";
        color = Colors.green;
        resta = 0;
      }else{
        texto = "¡Repuesta incorrecta!";
        color = Colors.red;
        resta = 10;
      }

      double ancho = MediaQuery.of(context).size.width/3;
      
      return Padding(
        padding: EdgeInsets.only(top: 16.0, left: ancho-resta, bottom: 16.0, right: 4.0),
        child: Align(
          alignment: Alignment.bottomLeft,
          child: Text(
            texto,
            style: TextStyle(
              color: color,
              fontWeight: bold?FontWeight.bold:FontWeight.normal,
              fontSize: size,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          textoPersonalizado(
            "c) ¿Cuáles fueron las dos ciudades más importantes durante el antiguo Egipto?",
            Colors.black,
            18,
            true
          ),
          SizedBox(height: 10),
          Row(
            children: [
              Radio(
                value: "1", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("a. Menfis y Roma", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "2", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("b. Atenas y Tebas", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "3", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                    score += 10;
                  });
                }:null,
                
              ),
              textoPersonalizado("c. Menfis y Tebas", Colors.black, 16, false),
            ],
          ),
          Row(
            children: [
              Radio(
                value: "4", 
                groupValue: respuesta, 
                onChanged: activarResponder?(val){
                  respuesta = val.toString();
                  setState(() {
                    activarResponder = false;
                  });
                }:null,
              ),
              textoPersonalizado("d. Persépolis y Babilonia", Colors.black, 16, false),
            ],
          ),
          SizedBox(height: 10),
          activarResponder?
          Container()
          :Align(
            alignment: Alignment.center,
            child: textoRespuesta(16, true)
          ),
          ElevatedButton(
            onPressed: activarResponder?null:(){
              print(score);
              Navigator.pushReplacement(
                context, 
                MaterialPageRoute(builder: (context) => Score())
              );
            }, 
            child: Text("Siguiente"),
            
          )
        ],
      )
    );
  }
}

//Clase Score: pantalla de la puntuación final del cuestionario
class Score extends StatefulWidget {
  const Score({ Key? key }) : super(key: key);

  @override
  _ScoreState createState() => _ScoreState();
}

class _ScoreState extends State<Score> {
  @override
  Widget build(BuildContext context) {

    //Método para crear widget de texto personalizado
    Widget textoPersonalizado(String texto, Color color, double size, bool bold){
      return Align(
        alignment: Alignment.center,
        child: Text(
          texto,
          style: TextStyle(
            color: color,
            fontWeight: bold?FontWeight.bold:FontWeight.normal,
            fontSize: size,
          ),
        ),
      );
    }

    //Estructura de la app
    return Scaffold(
      //Barra superior
      appBar: AppBar(),
      //Columna de widgets
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          //Llamada a método para crear texto personalizado
          textoPersonalizado(
            "Puntuación total:",
            Colors.black,
            28,
            true
          ),
          //Separador por 10 pixeles
          SizedBox(height: 10),
          //Widget que muestra el texto de la puntuación
          Center(
            child: textoPersonalizado(
              "${score.toString()}",
              Colors.blue,
              28,
              true
            ),
          ),
          //Botón para volver a responder el cuestionario
          ElevatedButton(
            onPressed: (){
              score = 0;
              print(score);
              //Llamada a la pantalla "MyApp" de la pregunta 1
              Navigator.pushReplacement(
                context, 
                MaterialPageRoute(builder: (context) => MyApp())
              );
            }, 
            //Texto del botón
            child: Text("Reintentar"),
            
          )
        ],
      )
    );
  }
}